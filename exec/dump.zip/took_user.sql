-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i11e205.p.ssafy.io    Database: took
-- ------------------------------------------------------
-- Server version	8.4.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `alarm` bit(1) NOT NULL,
  `image_no` int NOT NULL,
  `lat` double DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `simple_password` int DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `user_seq` bigint NOT NULL AUTO_INCREMENT,
  `role` varchar(10) NOT NULL,
  `birth` varchar(20) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `user_id` varchar(30) DEFAULT NULL,
  `user_name` varchar(30) DEFAULT NULL,
  `addr` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `gender` enum('F','M') DEFAULT NULL,
  `login_status` enum('GOOGLE','KAKAO','TOOK') NOT NULL,
  PRIMARY KEY (`user_seq`),
  UNIQUE KEY `UKa3imlf41l37utmxiquukk8ajc` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (_binary '',9,35.08950132584883,128.8533436559255,NULL,'2024-08-09 10:18:24.150208',1,'ROLE_USER','20010118','01077228267','a','차민주','송정삼정그린코아더시티오피스텔','ckalswn007@naver.com',NULL,'$2a$10$s5iuQq39expVsZPREkYGSeSzOCrF9v//XvHmvAxQppK7/LoL4dUQ.','F','TOOK'),(_binary '',17,35.08950132584883,128.8533436559255,NULL,'2024-08-09 10:18:33.928599',2,'ROLE_USER','19971224','01012345678','b','현정','송정삼정그린코아더시티오피스텔','whguswjd456@naver.com',NULL,'$2a$10$olcEckmop9inrFwO/ok4P.EE3HzeXoP/1WQwW.2zC6ChgMgUlFgeO','F','TOOK'),(_binary '',4,35.0936563177956,128.855672336864,NULL,'2024-08-09 10:19:37.694695',3,'ROLE_USER','19990101','01011111115','c','공지환','삼성전기 부산사업장 정문','ckalswn007@naver.com',NULL,'$2a$10$9p.aZrRKaqY5DNJ4WpnNzOC0An.SfHYfzimtEygwlSRDVNzgMKo3q','M','TOOK'),(_binary '',5,35.08950132584883,128.8533436559255,NULL,'2024-08-09 10:20:03.933081',4,'ROLE_USER','11111111','01011111111','d','김태훈','송정삼정그린코아더시티오피스텔','whguswjd456@naver.com',NULL,'$2a$10$enoRAfOEhhAX0NK9TQcggexo2VycZxhcuDRMm2M7dGWKwPX8EczUG','M','TOOK'),(_binary '',1,NULL,NULL,NULL,'2024-08-09 10:20:52.584000',5,'ROLE_USER','20010101','01045640000','e','정희수',NULL,'ckalswn007@naver.com',NULL,'$2a$10$ko5AsJhiGSu6sKENn1axDuTHkh2qHzb68HNaGDCIfELkV6pgREsYq','F','TOOK'),(_binary '',18,35.08950132584883,128.8533436559255,NULL,'2024-08-09 10:21:02.454693',6,'ROLE_USER','22222222','01022222222','f','이재찬','송정삼정그린코아더시티오피스텔','whguswjd456@naver.com',NULL,'$2a$10$.2Sw/c9Rqykj3MFvYakQDu7zRceSSWgcfMLyZZHlQrxG6vOmDKCN.','M','TOOK'),(_binary '',1,35.08950132584883,128.8533436559255,NULL,'2024-08-09 10:57:14.283850',7,'ROLE_USER','20010129','01066142769','q','정희수','송정삼정그린코아더시티오피스텔','s007kk@ajou.ac.kr',NULL,'$2a$10$9hToFYuyqHs0rGkufze8bu9DgD7.7OP.oNQd12kiqPw2uzKzGJNW2','F','TOOK'),(_binary '',3,35.09362371920619,128.85603563150357,NULL,'2024-08-09 14:26:01.538892',8,'ROLE_USER','20000101','01048018670','g','홍길동','삼성전기 부산사업장','jaechanjj@naver.com',NULL,'$2a$10$j8Xb9jsiuZFaksi1Fi0Bk.qwFlIuNnJV3GlGVh/gy0BSis.JF60e2','M','TOOK'),(_binary '',1,35.09362371920619,128.85603563150357,NULL,'2024-08-09 21:12:00.736907',9,'ROLE_USER','20010129','01066142769','s007kk','정희수','삼성전기 부산사업장','s007kk@ajou.ac.kr',NULL,'$2a$10$0vRgEW7h66kRpb22Lek2XufMY5CYEDoPLlqqw2.oWyS0j.qHJ2G/m','F','TOOK'),(_binary '',19,35.08950132584883,128.8533436559255,NULL,'2024-08-10 14:14:11.756282',10,'ROLE_USER','19980804','01043769807','zxader','김태훈','송정삼정그린코아더시티오피스텔','zxader@naver.com',NULL,'$2a$10$XjI7udin75AMsoGfkUS4uOAPMb4R5hfeZHHxOWD2cii7MzpoC2/8C','M','TOOK'),(_binary '',5,35.08950132584883,128.8533436559255,NULL,'2024-08-10 17:03:32.294040',11,'ROLE_USER','19991006','01087245334','rinch12332','공지환','송정삼정그린코아더시티오피스텔','rinch12332@gmail.com',NULL,'$2a$10$HNqptBEYqKl/PUsTzLvYRuKnIvwdvM8Hep/iANmIbNeekmY2UWvTe','M','TOOK'),(_binary '',3,NULL,NULL,NULL,'2024-08-10 18:23:52.847485',12,'ROLE_USER','19990409','01025335920','최지우','최지우',NULL,'andyandy0409@naver.com',NULL,'$2a$10$wU0QQcIHBNjlJQIBq9W/Vux6YQtmkdCceLlIGHrG44b2e/dSvYKRC','M','TOOK'),(_binary '',4,NULL,NULL,NULL,'2024-08-11 00:57:18.376611',13,'ROLE_USER','20010913','01012345612','j','정성찬',NULL,'ckalswn007@naver.com',NULL,'$2a$10$UNpXUWnI9xjstDyGWT40fuuUq8a2XQJEayeU/hwdUqC5p.OZ3yMvq','M','TOOK'),(_binary '',2,NULL,NULL,NULL,'2024-08-11 19:47:13.603173',14,'ROLE_USER','19980312','01090937493','icnwpe','김민욱',NULL,'kimmw2_@naver.com',NULL,'$2a$10$yJ9s0G.GJkL9yF2pmvJxvexLXQj8FjrNtsNFq50puUn/DgsYlNEHu','M','TOOK'),(_binary '',11,NULL,NULL,NULL,'2024-08-12 01:24:50.560807',15,'ROLE_USER','19970101','01011111111','k','차은우',NULL,'ckalswn007@naver.com',NULL,'$2a$10$Rhr.sXUXhcZKXhL7cEgfkul7ktck/Ih0XAVnBx56wVddOIhA6QiMm','M','TOOK'),(_binary '',16,NULL,NULL,NULL,'2024-08-12 01:27:01.502825',16,'ROLE_USER','19930311','01024565456','l','김명수',NULL,'ckalswn007@naver.com',NULL,'$2a$10$S6ebpHAnO8SlOcR4LQTLZ.p86DPhTYXt4mn/77d0uNGMzVsvImO9.','M','TOOK'),(_binary '',22,NULL,NULL,NULL,'2024-08-12 09:26:12.162407',17,'ROLE_USER','19901122','01012345678','silverhappy','전은희',NULL,'jeon78eun@naver.com',NULL,'$2a$10$LcWOucvMWIyej//g4fJrxOCRrLlxhu/dnTy/oscKe2FZRwkb4WEgO','F','TOOK'),(_binary '',9,NULL,NULL,NULL,'2024-08-12 11:13:20.770043',18,'ROLE_USER','19450815','01011111111','back','백종원',NULL,'qkrdusgn00@naver.com',NULL,'$2a$10$ONYRzfNxPBbmRBSrCqyo6eM0oxeOZWzUh7yrwjGGidlM/N.Jl3ch2','M','TOOK'),(_binary '',14,35.0936563177956,128.855672336864,NULL,'2024-08-12 16:45:02.298544',19,'ROLE_USER','20010129','01066142769','pp','정히수','삼성전기 부산사업장 정문','s007kk@ajou.ac.kr',NULL,'$2a$10$UExdNyaVrna0YVxKsBxw.O4EJp0ZbbjBQHI.RoP86mL0JS1pNIhi.','F','TOOK'),(_binary '',8,NULL,NULL,NULL,'2024-08-13 11:26:28.341577',20,'ROLE_USER','19971223','01011111111','hj','현정조',NULL,'whguswjd456@naver.com',NULL,'$2a$10$SkL.7hJQCT3Pjp9FUvuuReHQgl8i6R4ykZapcP4oYOl9gFvNoK6YS','F','TOOK'),(_binary '',23,35.09362371920619,128.85603563150357,NULL,'2024-08-13 11:26:38.920037',21,'ROLE_USER','20000107','01012345678','hay0107','한아영','삼성전기 부산사업장','hay0107@naver.com',NULL,'$2a$10$gf84QWqMSebYs/4aZ32o1.NFQCPDQGX7WfZNCvD0FgyU1ibniicCO','F','TOOK'),(_binary '',18,NULL,NULL,NULL,'2024-08-13 11:29:13.905523',22,'ROLE_USER','19940222','01099999999','n','남주혁',NULL,'whguswjd456@naver.com',NULL,'$2a$10$2duBrnMNAaIOHNRmZGQc2.KjHaMDdbxmnn1YmHFN9EVTiKgYXS7nu','M','TOOK'),(_binary '',11,NULL,NULL,NULL,'2024-08-13 11:34:12.840021',23,'ROLE_USER','19790701','00000000000','go','공유',NULL,'whguswjd456@naver.com',NULL,'$2a$10$WN.XpBzMZYx6EUtH.HtRqemjHPKmfiPewZbetTQvvarQi9WrhUAy6','M','TOOK'),(_binary '',3,35.08950132584883,128.8533436559255,NULL,'2024-08-13 12:09:38.357093',24,'ROLE_USER','11111111','01011111111','test','테스터','송정삼정그린코아더시티오피스텔','jaechanjj@naver.com',NULL,'$2a$10$P73WNRyl.J0g9PvkACsbsOvYHlGvMRaJZNyl.A1v4CzuM2FFgaNEm','M','TOOK');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-14 11:21:14
