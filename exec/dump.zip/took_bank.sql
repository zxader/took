-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i11e205.p.ssafy.io    Database: took
-- ------------------------------------------------------
-- Server version	8.4.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `account_pwd` int DEFAULT NULL,
  `bank_num` int DEFAULT NULL,
  `is_bank` bit(1) DEFAULT NULL,
  `balance` bigint DEFAULT NULL,
  `bank_seq` bigint NOT NULL AUTO_INCREMENT,
  `account_num` varchar(255) DEFAULT NULL,
  `own` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bank_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES (1111,1,_binary '',799204,1,'1234567890','조현정'),(1111,2,_binary '',2316870,2,'1234567891','정희수'),(1111,3,_binary '',1471499,3,'1234567892','차민주'),(1111,4,_binary '',2019158,4,'1234567893','김태훈'),(1111,5,_binary '',2501500,5,'1234567894','공지환'),(1111,6,_binary '',3418342,6,'1234567895','이재찬'),(1111,7,_binary '',1200000,7,'1234567896','조현정'),(1111,8,_binary '',2200000,8,'1234567897','정희수'),(1111,9,_binary '',1700000,9,'1234567898','차민주'),(1111,10,_binary '',3200000,10,'1234567899','김태훈'),(1111,11,_binary '',2700000,11,'1234567800','공지환'),(1111,12,_binary '',3700000,12,'1234567801','이재찬'),(1111,13,_binary '',1300000,13,'1234567802','조현정'),(1111,14,_binary '',2300000,14,'1234567803','정희수'),(1111,15,_binary '',1800000,15,'1234567804','차민주'),(1111,16,_binary '',3300000,16,'1234567805','김태훈'),(1111,17,_binary '',2880300,17,'1234567806','공지환'),(1111,18,_binary '',3800000,18,'1234567807','이재찬'),(1111,19,_binary '',1400000,19,'1234567808','조현정'),(1111,20,_binary '',2400000,20,'1234567809','정희수'),(1111,21,_binary '',1900000,21,'1234567810','차민주'),(1111,22,_binary '',3400000,22,'1234567811','김태훈'),(1111,23,_binary '',3040004,23,'1234567812','공지환'),(1111,24,_binary '',3900000,24,'1234567813','이재찬'),(1111,1,_binary '',100000000,25,'1234567890','전은희'),(1111,1,_binary '',1000000000,26,'111111111','test'),(1111,1,_binary '',1000000000,27,'222222222','master'),(1111,1,_binary '',10000000,28,'1234567899','김태훈');
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-14 11:21:12
