-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: i11e205.p.ssafy.io    Database: took
-- ------------------------------------------------------
-- Server version	8.4.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `taxi_guest`
--

DROP TABLE IF EXISTS `taxi_guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taxi_guest` (
  `cost` bigint NOT NULL,
  `desti_lat` double NOT NULL,
  `desti_lon` double NOT NULL,
  `route_rank` int NOT NULL,
  `guest_seq` bigint NOT NULL AUTO_INCREMENT,
  `taxi_seq` bigint NOT NULL,
  `user_seq` bigint NOT NULL,
  `desti_name` varchar(255) NOT NULL,
  PRIMARY KEY (`guest_seq`),
  KEY `FKcamwq5nwhs3h8o88h89hx4hp8` (`taxi_seq`),
  KEY `FKa7yamu5u7fkncfkd3k5jw7l5o` (`user_seq`),
  CONSTRAINT `FKa7yamu5u7fkncfkd3k5jw7l5o` FOREIGN KEY (`user_seq`) REFERENCES `user` (`user_seq`) ON DELETE CASCADE,
  CONSTRAINT `FKcamwq5nwhs3h8o88h89hx4hp8` FOREIGN KEY (`taxi_seq`) REFERENCES `taxi` (`taxi_seq`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxi_guest`
--

LOCK TABLES `taxi_guest` WRITE;
/*!40000 ALTER TABLE `taxi_guest` DISABLE KEYS */;
INSERT INTO `taxi_guest` VALUES (127000,35,128,1,61,19,5,'부산대학교'),(141100,35,128,1,202,49,13,'영진돼지국밥'),(115100,35,128,1,220,54,6,'영일대해수욕장'),(115100,35,128,1,235,54,4,'영일대해수욕장'),(23000,35.097195508119285,129.0260699211048,1,251,79,15,'자갈치역 부산1호선'),(35500,35.157939062512,129.059300883545,1,252,79,7,'서면역 부산1호선'),(33000,35.1727945202073,129.071093977334,1,259,83,1,'양정역 부산1호선'),(20000,35.1031581926258,128.999943470572,2,260,83,2,'대티역 부산1호선'),(20300,35.097195508119285,129.0260699211048,2,261,84,23,'자갈치역 부산1호선'),(4800,35.08950132584883,128.8533436559255,1,262,84,3,'송정삼정그린코아더시티오피스텔');
/*!40000 ALTER TABLE `taxi_guest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-14 11:21:18
